const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD) console.warn('WARNING: Set ADMIN_PASSWORD in your hosting environment before deploying publicly.');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'products.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
const sessions = new Map();
fs.mkdirSync(DATA_DIR, {recursive:true});
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]', 'utf8');
app.disable('x-powered-by');
app.use(express.json({limit:'2mb'}));
app.use(express.static(PUBLIC_DIR));
function readProducts(){try{const x=JSON.parse(fs.readFileSync(DATA_FILE,'utf8'));return Array.isArray(x)?x:[]}catch{return []}}
function writeProducts(items){fs.writeFileSync(DATA_FILE+'.tmp',JSON.stringify(items,null,2));fs.renameSync(DATA_FILE+'.tmp',DATA_FILE)}
function validWebUrl(s){try{const u=new URL(s);return ['http:','https:'].includes(u.protocol)}catch{return false}}
function auth(req,res,next){const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):'';const expiry=sessions.get(token);if(!expiry||expiry<Date.now()){sessions.delete(token);return res.status(401).json({error:'Please sign in again.'})}next()}
function clean(p,existing={}){const name=String(p.name||'').trim();const price=Number(p.price);const url=String(p.url||'').trim();if(!name||name.length>160)throw Error('Product name is required (max 160 characters).');if(!Number.isFinite(price)||price<0)throw Error('Enter a valid price.');if(!validWebUrl(url))throw Error('Enter a valid http:// or https:// destination link.');const oldPrice=p.oldPrice===''||p.oldPrice==null?'':Number(p.oldPrice);if(oldPrice!==''&&(!Number.isFinite(oldPrice)||oldPrice<0))throw Error('Enter a valid old price.');const image=String(p.image||existing.image||'').trim();if(image&&!image.startsWith('data:image/')&&!validWebUrl(image))throw Error('Image must be a valid URL or uploaded image.');if(image.length>1100000)throw Error('Image is too large. Use a smaller image.');return {id:existing.id||crypto.randomUUID(),name,price,oldPrice,category:['Electronics','Home','Fashion','Beauty','Other'].includes(p.category)?p.category:'Other',image,url,description:String(p.description||'').trim().slice(0,1000)}}
app.get('/api/products',(req,res)=>res.json({products:readProducts().map(({id,name,price,oldPrice,category,image,url,description})=>({id,name,price,oldPrice,category,image,url,description}))}));
app.post('/api/admin/login',(req,res)=>{if(!ADMIN_PASSWORD)return res.status(503).json({error:'Admin login is not configured. Set ADMIN_PASSWORD on your host.'});const supplied=String(req.body.password||'');const a=Buffer.from(supplied),b=Buffer.from(ADMIN_PASSWORD);if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return res.status(401).json({error:'Incorrect password.'});const token=crypto.randomBytes(32).toString('hex');sessions.set(token,Date.now()+8*60*60*1000);res.json({token,expiresIn:28800})});
app.post('/api/products',auth,(req,res)=>{try{const items=readProducts();const p=clean(req.body);items.unshift(p);writeProducts(items);res.status(201).json({product:p})}catch(e){res.status(400).json({error:e.message})}});
app.put('/api/products/:id',auth,(req,res)=>{try{const items=readProducts(),i=items.findIndex(p=>p.id===req.params.id);if(i<0)return res.status(404).json({error:'Product not found.'});items[i]=clean(req.body,items[i]);writeProducts(items);res.json({product:items[i]})}catch(e){res.status(400).json({error:e.message})}});
app.delete('/api/products/:id',auth,(req,res)=>{const items=readProducts(),next=items.filter(p=>p.id!==req.params.id);if(next.length===items.length)return res.status(404).json({error:'Product not found.'});writeProducts(next);res.json({ok:true})});
app.get('/admin',(req,res)=>res.sendFile(path.join(PUBLIC_DIR,'admin.html')));
app.get('*',(req,res)=>res.sendFile(path.join(PUBLIC_DIR,'index.html')));
app.listen(PORT,()=>console.log(`Store running on port ${PORT}`));
