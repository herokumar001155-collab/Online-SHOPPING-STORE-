# Public Online Store

This is a deployable starter project for a public shopping-link store. The public homepage is `/` and the password-protected product manager is `/admin`.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run `npm install`.
3. Set an admin password in your shell:
   - macOS/Linux: `export ADMIN_PASSWORD='use-a-long-unique-password'`
   - Windows PowerShell: `$env:ADMIN_PASSWORD='use-a-long-unique-password'`
4. Run `npm start`.
5. Open `http://localhost:3000` for the public store and `http://localhost:3000/admin` to manage products.

## Deploy publicly
Deploy this folder to a Node.js host that supports persistent disk/storage. Set `ADMIN_PASSWORD` as a secret environment variable. Set `DATA_DIR` to a persistent writable directory if your host provides one. If the host has an ephemeral filesystem, products may be lost on redeploy/restart; use a persistent database/storage service before relying on it for a real business.

## Important
- This starter project has a protected admin panel and server-side product storage, but it is not yet hosted online. You must deploy it to a hosting provider to get a public URL.
- Product name, price, image, description and destination URL are entered manually. Automatic retailer data retrieval requires approved retailer APIs or another permitted data source.
- Only add product images and links you have permission to use. Follow each affiliate program's rules and disclose affiliate links where required.
- Before production use, add HTTPS via your host, rate limiting, backups, a persistent database, and stronger session handling suitable for your deployment.
